import {Controller,Get, Param, Post, Body, Delete, Put, Patch } from '@nestjs/common';
import { TreinamentoService } from 'src/sevice/treinamento/treinamento.service';

@Controller('treinamento')
export class TreinamentoController {
    constructor(private readonly appService: TreinamentoService) { }

    @Get()
    getDados() {
      return this.appService.getDados()
    }

    @Put(':id') // → PUT Exemplo/epis/42 
  update(@Param('id') id: string, @Body() body: any) { return this.appService.update(Number(id), body); }

}
